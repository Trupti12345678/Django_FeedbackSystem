from django.apps import AppConfig


class FeedbackAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Feedback_App'
