
from django.shortcuts import render
from .form import EmployeeForm
from .models import Employee

def employee_view(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()  # Save the data to the database
            # return redirect('employee_success')
    else:
        form = EmployeeForm()

    return render(request, 'form.html', {'form': form})

def DisplayInfo(request):
    employee = Employee.objects.all()
    return render(request, 'section2.html', {'employees': employee})

