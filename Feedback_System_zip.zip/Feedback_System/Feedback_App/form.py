from django import forms

# class StudentsRegistrationForm(forms.Form):
#     name = forms.CharField()
#     email = forms.EmailField()
#     no = forms.IntegerField()

from .models import Employee

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = ['ename', 'eemail', 'eno']
