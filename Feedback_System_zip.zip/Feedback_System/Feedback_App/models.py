from django.db import models
from .validators import validate_phone_number


# Create your models here.
class Employee(models.Model):
    ename=models.CharField(max_length=60)
    eemail=models.EmailField(max_length=60)
    eno = models.CharField(validators=[validate_phone_number], max_length=17, blank=True)
