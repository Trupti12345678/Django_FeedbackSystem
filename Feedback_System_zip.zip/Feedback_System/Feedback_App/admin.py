from django.contrib import admin
from Feedback_App.models import Employee

class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['ename', 'eemail', 'eno']
# Register your models here.
admin.site.register(Employee,EmployeeAdmin)